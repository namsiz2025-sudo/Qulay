# قۇلاي تور دۇكىنى — QOLAY Website

بۇ تۈر سىز يوللىغان `qolay-android-source-v1.0.11.zip` تۈرىگە ماس كېلىدىغان ئايرىم تور دۇكىنىدۇر. Android تۈرى WebView ئارقىلىق `EXPO_PUBLIC_DOMAIN` دا بەلگىلەنگەن توربەتنى ئاچىدۇ؛ بۇ ZIP ئىچىدە ئەسلى دۇكاننىڭ تور كودى يوق ئىدى. شۇڭا بۇ تۈر يېڭى Next.js تور كۆرۈنمە يۈزى قىلىپ تەييارلاندى.

## بەتلەر
- `/` باشبەت
- `/shop` دۇكان ۋە مەھسۇلاتلار
- `/orders` زاكاسلىرىم
- `/topup` پۇل قاچىلاش
- `/account` ھېسابات / Telegram كىرىش ئورنى
- `/profile` شەخسىي ئۇچۇرلار
- `/feedback` پىكىر يوللاش
- `/guide` ياردەم
- `/privacy` مەخپىيەتلىك
- `/admin` باشقۇرۇش تاختىسىنىڭ كىرىش ئورنى

## كومپيۇتېردا ئىجرا قىلىش
```bash
npm install
npm run dev
```
ئاندىن `http://localhost:3000` نى ئېچىڭ.

## Vercel غا يوللاش
1. ZIP نى ئېچىپ GitHub دا يېڭى repository قۇرۇپ ھۆججەتلەرنى يۈكلەڭ.
2. Vercel دا **Add New → Project** نى بېسىپ repository نى تاللاڭ.
3. Framework نى Next.js قىلىپ قويۇڭ؛ Build Command `npm run build`، Output Directory نى بوش قالدۇرۇڭ.
4. Deploy نى بېسىڭ.
5. Android تۈرىنىڭ `EXPO_PUBLIC_DOMAIN` قىممىتىگە Vercel تور نامىنى (https:// نى قوشماي) كىرگۈزۈڭ.

## مۇھىم: ھازىرقى ئىقتىدار ھالىتى
بۇ نۇسخا تور كۆرۈنمە يۈزى ۋە بەت يوللىرىنى تەييارلايدۇ. پۇل ھەقىقىي يۆتكەش، Telegram كىرىش، زاكاس ساقلاش، قالدۇق ھېسابلاش ۋە admin تەستىقلاش تېخى ئۇلانمىغان؛ UI بۇنى ئېنىق كۆرسىتىدۇ، ساختا ھەقىقىي ھەرىكەت دەپ كۆرسەتمەيدۇ.

ھەقىقىي ئىقتىدارلارنى قوزغىتىش ئۈچۈن:
- Supabase project قۇرۇپ `supabase/schema.sql` نى SQL Editor دا ئىجرا قىلىڭ.
- `.env.example` نى `.env.local` غا كۆچۈرۈپ Supabase URL/anon key نى قوشۇڭ.
- Telegram bot نىڭ توكىنى پەقەت server-side env دا ساقلاپ، Telegram Login validation endpoint قوشۇڭ.
- ShamCash نىڭ ھەقىقىي API base URL، API token ۋە callback/webhook تەلىپىنى تەمىنلەپ، server-side payment integration قوشۇڭ.
- admin رولىنى server-side دا دەلىللەڭ؛ ھەرگىز پەقەت يوشۇرۇن بەت ياكى client-side check قا تايانماڭ.

## بىخەتەرلىك
- BOT_TOKEN، API_TOKEN ياكى Supabase service role key نى كودقا يېزىپ قويماڭ.
- `NEXT_PUBLIC_` ئالدى قوشۇلغۇچىسى بار ئۆزگەرگۈچىلەر تور كۆرگۈچىگە ئاشكارا بولىدۇ؛ مەخپىي ئاچقۇچلارغا ئىشلەتمەڭ.
- پۇل قالدۇقىنى client/localStorage دىن ھېسابلىماڭ؛ مۇلازىمېتىر سانداندا ledger ئارقىلىق باشقۇرۇڭ.
