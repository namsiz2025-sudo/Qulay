import type { Metadata } from 'next';
import './globals.css';
import { SiteShell } from '@/components/SiteShell';
export const metadata: Metadata = { title: 'قۇلاي — تور دۇكىنى', description: 'قۇلاي تور دۇكىنى: مەھسۇلات، زاكاس ۋە ھېسابات باشقۇرۇش' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="ug" dir="rtl"><body><SiteShell>{children}</SiteShell></body></html>; }
