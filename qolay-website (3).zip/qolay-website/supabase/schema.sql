-- QOLAY starter database schema (Supabase/PostgreSQL)
create extension if not exists pgcrypto;
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  telegram_id text unique,
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text not null default '',
  price numeric(12,2) not null check (price >= 0),
  old_price numeric(12,2),
  category text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  product_id uuid not null references public.products(id),
  account_detail text not null,
  note text,
  amount numeric(12,2) not null check (amount >= 0),
  status text not null default 'pending' check (status in ('pending','processing','completed','rejected','cancelled')),
  created_at timestamptz not null default now()
);
create table if not exists public.topups (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  amount numeric(12,2) not null check (amount > 0),
  method text not null,
  payment_reference text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);
create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id),
  kind text not null,
  message text not null,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.topups enable row level security;
alter table public.feedback enable row level security;
create policy "active products are public" on public.products for select using (active = true);
create policy "users read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
create policy "users read own orders" on public.orders for select to authenticated using (auth.uid() = user_id);
create policy "users create own orders" on public.orders for insert to authenticated with check (auth.uid() = user_id);
create policy "users read own topups" on public.topups for select to authenticated using (auth.uid() = user_id);
create policy "users create own topups" on public.topups for insert to authenticated with check (auth.uid() = user_id);
create policy "users create feedback" on public.feedback for insert to authenticated with check (auth.uid() = user_id);
-- Admin-only update/approval policies must be added after defining a trusted admin role.
